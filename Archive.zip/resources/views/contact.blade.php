@extends('layouts.app')

@section('content')

	<div class="contact-page">
		<div class="contact-header"></div>
		@livewire('contact.form')
	</div>

@endsection