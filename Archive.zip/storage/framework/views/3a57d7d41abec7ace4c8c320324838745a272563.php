<div class="apply-form">
   <div class="container">
      
      <div class="row form-row">
         <div class="col-md-10 mx-auto">
            <div class="apply-for-loan-form position-relative overflow-hidden"
            <?php if($eligible): ?>
               style="background-image: url('/img/apply-form/clip-art.png');"
            <?php endif; ?>
            >

               <div class="loading-state" wire:loading>
                  <div class="spinner-box">
                     <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                     </div>
                  </div>
               </div>

               <?php if($formApply): ?>
                  <form wire:submit.prevent="submit">
                     <div class="heading">
                        How much money can I get?
                     </div>
                     <h5>About You</h5>
                     <div class="row">
                        <div class="col-md-6">
                           <div class="form-group">
                              <input type="text" class="form-control" wire:model.defer="firstName" placeholder="First Name">
                              <?php $__errorArgs = ['firstName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <input type="text" class="form-control" wire:model.defer="lastName" placeholder="Last Name">
                              <?php $__errorArgs = ['lastName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-12">
                           <div class="form-group">
                              <input type="text" class="form-control" wire:model.defer="email" placeholder="Email Address">
                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <input type="text" class="form-control" wire:model.defer="cellPhone" placeholder="Cell Phone (Optional)">
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <input type="text" class="form-control" wire:model.defer="zipCode" placeholder="Zip Code">
                              <?php $__errorArgs = ['zipCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <select class="form-select" wire:model.defer="state">
                                 <option disabled value="0">Select State</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                              </select>
                              <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-md-6">
                           <div class="form-group">
                              <select class="form-select" wire:model.defer="city">
                                 <option disabled value="0">Select City</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                              </select>
                              <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                     </div>
                     <h5>About Your Vehicle</h5>
                     <div class="row">
                        <div class="col-12">
                           <div class="form-group">
                              <select class="form-select" wire:model.defer="vehicleType">
                                 <option disabled value="0">Vehicle Type</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                              </select>
                              <?php $__errorArgs = ['vehicleType'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-lg col-md-6">
                           <div class="form-group">
                              <select class="form-select" wire:model.defer="year">
                                 <option disabled value="0">Year</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                              </select>
                              <?php $__errorArgs = ['year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-lg col-md-6">
                           <div class="form-group">
                              <select class="form-select" wire:model.defer="make">
                                 <option disabled value="0">Make</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                              </select>
                              <?php $__errorArgs = ['make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-lg col-md-4">
                           <div class="form-group">
                              <select class="form-select" wire:model.defer="model">
                                 <option disabled value="0">Model</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                              </select>
                              <?php $__errorArgs = ['model'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-lg col-md-4">
                           <div class="form-group">
                              <select class="form-select" wire:model.defer="trim">
                                 <option disabled value="0">Trim</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                              </select>
                              <?php $__errorArgs = ['trim'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                        <div class="col-lg col-md-4">
                           <div class="form-group">
                              <select class="form-select" wire:model.defer="mileage">
                                 <option disabled value="0">Mileage</option>
                                 <option value="1">One</option>
                                 <option value="2">Two</option>
                                 <option value="3">Three</option>
                              </select>
                              <?php $__errorArgs = ['mileage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="input_error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col-12 text-end">
                           <button type="submit" class="btn mt-5">
                           <span>Find Out Now</span>
                           <img src="<?php echo e(asset('icons/arrow-right-white.svg')); ?>" alt="right arrow">
                           </button>
                        </div>
                     </div>
                  </form>
               <?php endif; ?>

               
               <?php if($eligible): ?>
                  <div class="row eligible">
                     <div class="col-12 text-center header">
                        <img src="<?php echo e(asset('/img/apply-form/badge.png')); ?>" alt="badge" class="congrat-badge">
                        <h1 class="section-title">
                           Congratulations...
                        </h1>
                        <p>
                           You quality for up to
                        </p>
                        <div class="upto-value">
                           $ 24,800
                        </div>
                     </div>
                     <div class="col-12 body">
                        <div class="row">
                           <div class="col-md">
                              <p>
                                 *This is an estimate based on information you provided about your vehicle assuming standard equipment. Qualified amount may change based on actual equipment on car. All loans subject to vehicle appraisal and application approval. Certain terms and conditions apply. Must be 18 years of age or older
                              </p>
                           </div>
                           <div class="col-md-1">
                              <div class="line-border"></div>
                           </div>
                           <div class="col-md">
                              <p><span>Year : </span><?php echo e($year); ?></p>
                              <p><span>Make : </span><?php echo e($make); ?></p>
                              <p><span>Model : </span><?php echo e($model); ?></p>
                              <p><span>Trim : </span><?php echo e($trim); ?></p>
                              <p><span>Mileage : </span><?php echo e($mileage); ?></p>
                           </div>
                        </div>
                     </div>
                     <div class="col-12 footer text-end mt-5">
                        <a href="#" class="btn">Apply Now</a>
                     </div>
                  </div>
               <?php endif; ?>

            </div>
         </div>
      </div>
      
   </div>
</div><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/livewire/apply-form/form.blade.php ENDPATH**/ ?>