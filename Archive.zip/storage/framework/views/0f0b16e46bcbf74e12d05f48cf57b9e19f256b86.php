<?php $__env->startSection('content'); ?>
	
	<div class="all-blogs-page">
		
		
		<div class="blogs-header">
			<div class="container">
				<div class="row">
					<div class="col-12">
						<div class="blog-header">
							<h1 class="section-title">
								Blogs & News
							</h1>
							<p>
								Discover all posts from our blog
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blogs.all-blogs')->html();
} elseif ($_instance->childHasBeenRendered('cqIsrj4')) {
    $componentId = $_instance->getRenderedChildComponentId('cqIsrj4');
    $componentTag = $_instance->getRenderedChildComponentTagName('cqIsrj4');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cqIsrj4');
} else {
    $response = \Livewire\Livewire::mount('blogs.all-blogs');
    $html = $response->html();
    $_instance->logRenderedChild('cqIsrj4', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/blogs/index.blade.php ENDPATH**/ ?>