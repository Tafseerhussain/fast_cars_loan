<?php $__env->startSection('content'); ?>

    <?php if (isset($component)) { $__componentOriginal5380caaa5cce9d5625aeb62609c3748fa55f50bb = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\HomeHero::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('home-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\HomeHero::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5380caaa5cce9d5625aeb62609c3748fa55f50bb)): ?>
<?php $component = $__componentOriginal5380caaa5cce9d5625aeb62609c3748fa55f50bb; ?>
<?php unset($__componentOriginal5380caaa5cce9d5625aeb62609c3748fa55f50bb); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginalcfac4d9c65ff4432311bcd9a8a82b8c250572aab = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\EasySteps::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('easy-steps'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\EasySteps::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcfac4d9c65ff4432311bcd9a8a82b8c250572aab)): ?>
<?php $component = $__componentOriginalcfac4d9c65ff4432311bcd9a8a82b8c250572aab; ?>
<?php unset($__componentOriginalcfac4d9c65ff4432311bcd9a8a82b8c250572aab); ?>
<?php endif; ?>

    <?php if(Route::has('login')): ?>
        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(url('/home')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Home</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loanz/resources/views/welcome.blade.php ENDPATH**/ ?>