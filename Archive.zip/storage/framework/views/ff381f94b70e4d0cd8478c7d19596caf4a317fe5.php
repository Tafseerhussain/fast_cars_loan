<div class="faq-body">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="accordion" id="accordionFaq">

                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php if($loop->first): ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo e($faq->id); ?>">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($faq->id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($faq->id); ?>">
                                    <?php echo e($faq->title); ?>

                                </button>
                                </h2>
                                <div id="collapse<?php echo e($faq->id); ?>" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionFaq">
                                    <div class="accordion-body">
                                        <?php echo e($faq->description); ?>

                                    </div>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="heading<?php echo e($faq->id); ?>">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($faq->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($faq->id); ?>">
                                    <?php echo e($faq->title); ?>

                                </button>
                                </h2>
                                <div id="collapse<?php echo e($faq->id); ?>" class="accordion-collapse collapse" aria-labelledby="heading<?php echo e($faq->id); ?>" data-bs-parent="#accordionFaq">
                                    <div class="accordion-body">
                                        <?php echo e($faq->description); ?>

                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/components/faq/faqs.blade.php ENDPATH**/ ?>