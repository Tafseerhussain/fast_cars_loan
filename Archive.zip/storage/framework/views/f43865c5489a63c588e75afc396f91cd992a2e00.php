<div class="all-blogs">
    <div class="container">
        <div class="row blog-filters">
            
            <div class="col-md-4">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="blogFilter1" checked
                    wire:click="updateFilter('recent')">
                    <label class="form-check-label" for="blogFilter1">
                        Recent Posts
                    </label>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="blogFilter" 
                    wire:click="updateFilter('old')">
                    <label class="form-check-label" for="blogFilter">
                        Oldest Posts
                    </label>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="flexRadioDefault" id="blogFilter2"
                    wire:click="updateFilter('random')">
                    <label class="form-check-label" for="blogFilter2">
                        Random Posts
                    </label>
                </div>
            </div>
        </div>

        
        <div class="rows blog-cards">
            <div class="col-12">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="blog-card">
                        <div class="blog-card-img">
                            <img src="<?php echo e(asset('img/blog/all-blog.jpg')); ?>" alt="blog image">
                        </div>
                        <div class="blog-meta">
                            <h1 class="blog-title">
                                <?php echo e($blog->title); ?>

                            </h1>
                            <p>
                                <?php echo e($blog->short_description); ?>

                            </p>
                            <a href="#">Read More <img src="<?php echo e(asset('icons/right-arrow-green.svg')); ?>" alt="right arrow"></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div wire:loading>
                    Loading...
                </div>
                <?php echo e($blogs->links()); ?>

            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/livewire/blogs/all-blogs.blade.php ENDPATH**/ ?>