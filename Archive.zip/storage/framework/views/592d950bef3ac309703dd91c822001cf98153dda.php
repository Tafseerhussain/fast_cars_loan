<div class="why-get-funded">
   <div class="container">
       <div class="row">
           <div class="col-12 text-center text-white">
               <h1>
                   Why Get Funded With the Help of FastCarsMoney Title Loans?
               </h1>
               <p>
                   <span>Title Loan Benefits</span> You can get today.
               </p>
           </div>
       </div>
       <div class="row funded-cards">
           <div class="col-lg-3 col-md-6">
               <div class="funded-card shadow">
                   <div class="funded-card-img">
                       <img src="<?php echo e(asset('img/home/fast-cash.svg')); ?>" alt="fast-cash">
                       <h2>
                           Get Cash Fast
                       </h2>
                       <p>
                           Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
                       </p>
                   </div>
               </div>
           </div>
           <div class="col-lg-3 col-md-6">
               <div class="funded-card shadow">
                   <div class="funded-card-img">
                       <img src="<?php echo e(asset('img/home/keep-car.svg')); ?>" alt="keep-car">
                       <h2>
                           Keep Your Car
                       </h2>
                       <p>
                           Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
                       </p>
                   </div>
               </div>
           </div>
           <div class="col-lg-3 col-md-6">
               <div class="funded-card shadow">
                   <div class="funded-card-img">
                       <img src="<?php echo e(asset('img/home/bad-credit.svg')); ?>" alt="bad-credit">
                       <h2>
                           Bad Credit OK
                       </h2>
                       <p>
                           Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
                       </p>
                   </div>
               </div>
           </div>
           <div class="col-lg-3 col-md-6">
               <div class="funded-card shadow">
                   <div class="funded-card-img">
                       <img src="<?php echo e(asset('img/home/convenient-terms.svg')); ?>" alt="convenient-terms">
                       <h2>
                           Convenient Terms
                       </h2>
                       <p>
                           Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's
                       </p>
                   </div>
               </div>
           </div>
       </div>
   </div>
</div><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/components/why-get-funded.blade.php ENDPATH**/ ?>