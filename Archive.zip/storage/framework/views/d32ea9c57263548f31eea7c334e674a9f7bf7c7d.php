<div class="easy-steps" id="easy-steps">
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h1 class="section-title text-center">
                    3 Easy Steps to Apply for Fast Title Loans Online or Near You!
                </h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md border">
                test
            </div>
            <div class="col-md offset-md-1 border">
                test
            </div>
            <div class="col-md offset-md-1 border">
                test
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/MAMP/htdocs/fast_cars_loanz/resources/views/components/easy-steps.blade.php ENDPATH**/ ?>