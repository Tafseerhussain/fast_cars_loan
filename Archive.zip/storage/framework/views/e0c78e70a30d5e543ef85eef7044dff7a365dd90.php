<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('apply-form.form')->html();
} elseif ($_instance->childHasBeenRendered('FO4vY36')) {
    $componentId = $_instance->getRenderedChildComponentId('FO4vY36');
    $componentTag = $_instance->getRenderedChildComponentTagName('FO4vY36');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FO4vY36');
} else {
    $response = \Livewire\Livewire::mount('apply-form.form');
    $html = $response->html();
    $_instance->logRenderedChild('FO4vY36', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/components/apply-form/form.blade.php ENDPATH**/ ?>