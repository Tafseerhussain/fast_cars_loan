@extends('layouts.app')

@section('content')
	
	<div class="title-loan-page">
		<x-title-loan.hero/>
		<x-title-loan.call-box/>
		<x-title-loan.how-to/>
		<x-title-loan.title-loan-benefits/>
	</div>

@endsection