<div class="loan-left">
    <h4>Watch this short video to learn How Title Loans Work</h4>
    <div class="loan-video">
        <iframe 
            src="https://iframe.videodelivery.net/e38cc282b1a22ea34652995035f210b2?preload=true&loop=false&autoplay=false&controls=true"
            width="100%" 
            height="100%" 
            allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;" 
            allowfullscreen="true"
            frameborder="0" 
            scrolling="no"
            id="stream-player">
        </iframe>
    </div>
    <p>
        Getting car title loans or motorcycle title loans with TitleMax® is easy! The entire process can be completed in as little as 30 minutes.
    </p>
    <a href="{{ route('apply-form') }}" class="btn">
        Apply for Loan
    </a>
</div>