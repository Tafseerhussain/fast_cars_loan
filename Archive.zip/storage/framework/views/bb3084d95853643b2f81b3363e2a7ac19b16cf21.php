<?php $__env->startSection('content'); ?>

	<div class="apply-form-page">

		<div class="apply-form-header">
		    <div class="container">
		        <div class="row">
		            <div class="col-lg-6 col-md-8 mx-auto text-center">
		                <h1 class="section-title text-white">
		                    Find Out How Much Cash You Can Get Within Minutes!
		                </h1>
		                <p class="text-white">
		                    Offering Title-Secured, Personal, and Online options!
		                </p>
		            </div>
		        </div>
		    </div>
		</div>

		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('apply-form.form')->html();
} elseif ($_instance->childHasBeenRendered('kFnUdsj')) {
    $componentId = $_instance->getRenderedChildComponentId('kFnUdsj');
    $componentTag = $_instance->getRenderedChildComponentTagName('kFnUdsj');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kFnUdsj');
} else {
    $response = \Livewire\Livewire::mount('apply-form.form');
    $html = $response->html();
    $_instance->logRenderedChild('kFnUdsj', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/apply-form.blade.php ENDPATH**/ ?>