<div class="about-hero">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <h1>
                    About Us
                </h1>
                <p>
                    FastCarsMoney Loans has been passionate about creating a superior level respect and understanding for our customers.
                </p>
                <a href="<?php echo e(route('apply-form')); ?>" class="btn">Apple for Loan</a>
            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/components/about/hero.blade.php ENDPATH**/ ?>