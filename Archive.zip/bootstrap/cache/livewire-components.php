<?php return array (
  'apply-form.form' => 'App\\Http\\Livewire\\ApplyForm\\Form',
  'blogs.all-blogs' => 'App\\Http\\Livewire\\Blogs\\AllBlogs',
  'contact.form' => 'App\\Http\\Livewire\\Contact\\Form',
);