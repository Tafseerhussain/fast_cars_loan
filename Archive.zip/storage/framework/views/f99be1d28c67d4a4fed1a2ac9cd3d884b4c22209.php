<?php $__env->startSection('content'); ?>
	
	<div class="privacy-policy-page">
		<div class="policy-header">
			<div class="container">
				<div class="row">
					<div class="col-md-10 mx-auto text-center">
						<h1 class="text-white">
							Privacy Policy
						</h1>
						<p class="text-white opacity-50">
							Your Privacy is important to us and FastCarsMoney Limited is committed to protecting your privacy whilst providing a personalized and valuable service.
						</p>
					</div>
				</div>
			</div>
		</div>

		<?php if (isset($component)) { $__componentOriginal8415686113689a8dbee8672b2166c01978d9fa70 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Policy\Privacy::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('policy.privacy'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Policy\Privacy::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8415686113689a8dbee8672b2166c01978d9fa70)): ?>
<?php $component = $__componentOriginal8415686113689a8dbee8672b2166c01978d9fa70; ?>
<?php unset($__componentOriginal8415686113689a8dbee8672b2166c01978d9fa70); ?>
<?php endif; ?>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/privacy-policy.blade.php ENDPATH**/ ?>