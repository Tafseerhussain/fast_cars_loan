<div class="loan-apply">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 text-center">
                <h1 class="section-title text-white">
                    Less than 30 minutes to get your loan.
                </h1>
                <a href="<?php echo e(route('apply-form')); ?>" class="btn btn-outline">
                    Apply for Loan
                </a>
            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/components/how-title-loan-works/loan-apply.blade.php ENDPATH**/ ?>