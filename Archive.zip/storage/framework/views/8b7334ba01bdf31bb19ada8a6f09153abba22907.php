<div class="how-loan-works">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="loan-left">
                    <h4>Watch this short video to learn How Title Loans Work</h4>
                    <div class="loan-video">
                        <iframe 
                            src="https://iframe.videodelivery.net/e38cc282b1a22ea34652995035f210b2?preload=true&loop=false&autoplay=false&controls=true"
                            width="100%" 
                            height="100%" 
                            allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture;" 
                            allowfullscreen="true"
                            frameborder="0" 
                            scrolling="no"
                            id="stream-player">
                        </iframe>
                    </div>
                    <p>
                        Getting car title loans or motorcycle title loans with TitleMax® is easy! The entire process can be completed in as little as 30 minutes.
                    </p>
                    <a href="#" class="btn">
                        Apply for Loan
                    </a>
                </div>
            </div>
            <div class="col-md-5 offset-md-1">
                <div class="loan-right">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.common.hero-form','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('common.hero-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/components/how-loan-works/hero.blade.php ENDPATH**/ ?>