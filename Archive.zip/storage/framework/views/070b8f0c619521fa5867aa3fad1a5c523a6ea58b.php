<?php $__env->startSection('content'); ?>

	<div class="faq-page">
		<div class="faq-header">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-8">
						<h1 class="section-title text-white">
							Frequently Asked Questions
						</h1>
						<p class="text-white opacity-50">
							We are here to help. If the answer to your question is not listed below,
						</p>
					</div>
				</div>
			</div>
		</div>
		<?php if (isset($component)) { $__componentOriginala8995a5bf06a58af95d69daca9b6c647ebf0855a = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Faq\Faqs::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('faq.faqs'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Faq\Faqs::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala8995a5bf06a58af95d69daca9b6c647ebf0855a)): ?>
<?php $component = $__componentOriginala8995a5bf06a58af95d69daca9b6c647ebf0855a; ?>
<?php unset($__componentOriginala8995a5bf06a58af95d69daca9b6c647ebf0855a); ?>
<?php endif; ?>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/faq.blade.php ENDPATH**/ ?>