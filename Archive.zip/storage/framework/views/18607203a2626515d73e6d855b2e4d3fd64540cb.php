<div class="privacy-policy-detail">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h1>Privacy Policy</h1>
            </div>
            <div class="col-md-5">
                <div class="card border rounded shadow">
                    <h1>Test</h1>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/components/policy/privacy.blade.php ENDPATH**/ ?>