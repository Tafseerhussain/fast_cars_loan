@extends('layouts.app')

@section('content')

	<div class="advantages-page">
		<x-advantages.hero/>
		<x-advantages.advantage-boxes/>
		<x-advantages.get-your-loan/>
	</div>

@endsection