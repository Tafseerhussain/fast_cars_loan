<?php $__env->startSection('content'); ?>

	<div class="contact-page">
		<div class="contact-header"></div>
		<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('contact.form')->html();
} elseif ($_instance->childHasBeenRendered('mYxxsJk')) {
    $componentId = $_instance->getRenderedChildComponentId('mYxxsJk');
    $componentTag = $_instance->getRenderedChildComponentTagName('mYxxsJk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('mYxxsJk');
} else {
    $response = \Livewire\Livewire::mount('contact.form');
    $html = $response->html();
    $_instance->logRenderedChild('mYxxsJk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/fast_cars_loan/resources/views/contact.blade.php ENDPATH**/ ?>